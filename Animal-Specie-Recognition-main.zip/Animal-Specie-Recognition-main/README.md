# Animal-Specie-Recognition
Testing out RESNET-50 for animal specie recognition
1. Open the project in vs code and open the terminal and follow these commands
2. pip install virtualenv
3. virtualenv env
4. env/Scripts/activate (for windows )
5. after that run this command : pip install -r requirements.txt
6. then run this streamlit run app.py
7. Enjoy :)
